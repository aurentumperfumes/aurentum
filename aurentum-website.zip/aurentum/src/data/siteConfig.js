/**
 * =====================================================================
 * AURENTUM — SITE CONFIGURATION
 * =====================================================================
 * Edit these values with your real business details before launch.
 * Everything marked with ⚠ PLACEHOLDER must be changed.
 * =====================================================================
 */

export const SITE = {
  brandName: "AURENTUM",
  tagline: "Crafted For Confidence",
  legalName: "AURENTUM ⚠ PLACEHOLDER — your registered business name",
  currency: "NPR",

  // ⚠ PLACEHOLDER — replace with your real WhatsApp business number,
  // in international format with no spaces or symbols (e.g. 9779800000000)
  whatsappNumber: "9779800000000",

  // ⚠ PLACEHOLDER — replace with your real contact details
  email: "hello@aurentum.example.com",
  phone: "+977 98-0000-0000",
  address: "⚠ PLACEHOLDER — street address, City, Nepal",

  social: {
    instagram: "https://instagram.com/aurentum", // ⚠ PLACEHOLDER
    facebook: "https://facebook.com/aurentum", // ⚠ PLACEHOLDER
    tiktok: "", // leave blank to hide
  },

  // Provinces of Nepal, used in the checkout address form
  provinces: [
    "Koshi",
    "Madhesh",
    "Bagmati",
    "Gandaki",
    "Lumbini",
    "Karnali",
    "Sudurpashchim",
  ],

  shipping: {
    freeShippingThreshold: 10000, // NPR — set to 0 to disable
    flatRate: 150, // NPR, charged below the free-shipping threshold
    estimateInsideValley: "1–2 business days", // ⚠ PLACEHOLDER
    estimateOutsideValley: "3–5 business days", // ⚠ PLACEHOLDER
  },
};
