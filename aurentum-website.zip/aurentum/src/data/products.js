/**
 * =====================================================================
 * AURENTUM — PRODUCT DATA FILE
 * =====================================================================
 * This is the ONLY file you need to edit to change what's for sale.
 *
 * Every product below is a PLACEHOLDER. Prices, fragrance notes and
 * descriptions are marked isPlaceholder: true and must be replaced with
 * your real, factual product information before you launch — nothing
 * here is a genuine brand claim.
 *
 * HOW TO ADD A REAL PRODUCT PHOTO
 * 1. Drop your image file(s) into: public/products/
 *    e.g. public/products/velours-noir-1.jpg
 * 2. Reference it below as: "/products/velours-noir-1.jpg"
 * 3. Until you add a real photo, the site shows an elegant line-art
 *    bottle placeholder automatically — nothing will look "broken".
 *
 * FIELD GUIDE
 * id            – unique URL slug, lowercase-with-dashes
 * name          – product name shown everywhere
 * tagline       – short one-line descriptor (Shop grid + hero cards)
 * price         – number, in NPR (Nepali Rupee), no commas/symbols
 * sizes         – array of { label, ml, priceOverride? }
 * stock         – "in-stock" | "low-stock" | "out-of-stock"
 * concentration – e.g. "Eau de Parfum", "Parfum"
 * family        – fragrance family used for shop filtering
 * images        – array of image paths (first = primary)
 * notes         – { top, heart, base } fragrance pyramid, each an array
 * description   – 2–4 sentence product story
 * isPlaceholder – true = flagged to you as needing real info
 * featured      – true = eligible to appear in Home "Featured" section
 * =====================================================================
 */

export const PRODUCTS = [
  {
    id: "velours-noir",
    name: "Velours Noir",
    tagline: "Dark amber, worn like silk.",
    price: 6500,
    sizes: [
      { label: "30 ml", ml: 30 },
      { label: "50 ml", ml: 50, priceOverride: 8900 },
      { label: "100 ml", ml: 100, priceOverride: 12900 },
    ],
    stock: "in-stock",
    concentration: "Eau de Parfum",
    family: "Amber & Woods",
    images: ["/products/velours-noir-1.jpg", "/products/velours-noir-2.jpg"],
    notes: {
      top: ["Placeholder — e.g. Bergamot", "Placeholder — e.g. Pink Pepper"],
      heart: ["Placeholder — e.g. Amber", "Placeholder — e.g. Suede"],
      base: ["Placeholder — e.g. Sandalwood", "Placeholder — e.g. Musk"],
    },
    description:
      "PLACEHOLDER DESCRIPTION — replace with your real product story. Keep it short: what it feels like to wear, and the mood it's built for.",
    isPlaceholder: true,
    featured: true,
  },
  {
    id: "lumiere-blanche",
    name: "Lumière Blanche",
    tagline: "White florals, cool as morning air.",
    price: 6200,
    sizes: [
      { label: "30 ml", ml: 30 },
      { label: "50 ml", ml: 50, priceOverride: 8500 },
    ],
    stock: "in-stock",
    concentration: "Eau de Parfum",
    family: "Floral",
    images: ["/products/lumiere-blanche-1.jpg"],
    notes: {
      top: ["Placeholder — e.g. Bergamot", "Placeholder — e.g. Mandarin"],
      heart: ["Placeholder — e.g. Jasmine", "Placeholder — e.g. Iris"],
      base: ["Placeholder — e.g. White Musk", "Placeholder — e.g. Cedar"],
    },
    description:
      "PLACEHOLDER DESCRIPTION — replace with your real product story. Keep it short: what it feels like to wear, and the mood it's built for.",
    isPlaceholder: true,
    featured: true,
  },
  {
    id: "ambre-royal",
    name: "Ambre Royal",
    tagline: "A warm signature, unmistakably yours.",
    price: 7200,
    sizes: [
      { label: "30 ml", ml: 30 },
      { label: "50 ml", ml: 50, priceOverride: 9800 },
      { label: "100 ml", ml: 100, priceOverride: 13900 },
    ],
    stock: "low-stock",
    concentration: "Parfum",
    family: "Amber & Woods",
    images: ["/products/ambre-royal-1.jpg"],
    notes: {
      top: ["Placeholder — e.g. Saffron", "Placeholder — e.g. Cardamom"],
      heart: ["Placeholder — e.g. Rose", "Placeholder — e.g. Oud"],
      base: ["Placeholder — e.g. Amber", "Placeholder — e.g. Vanilla"],
    },
    description:
      "PLACEHOLDER DESCRIPTION — replace with your real product story. Keep it short: what it feels like to wear, and the mood it's built for.",
    isPlaceholder: true,
    featured: true,
  },
  {
    id: "vetiver-sauvage",
    name: "Vétiver Sauvage",
    tagline: "Green, grounded, quietly confident.",
    price: 5900,
    sizes: [
      { label: "30 ml", ml: 30 },
      { label: "50 ml", ml: 50, priceOverride: 7900 },
    ],
    stock: "in-stock",
    concentration: "Eau de Parfum",
    family: "Woody & Green",
    images: ["/products/vetiver-sauvage-1.jpg"],
    notes: {
      top: ["Placeholder — e.g. Grapefruit", "Placeholder — e.g. Mint"],
      heart: ["Placeholder — e.g. Vetiver", "Placeholder — e.g. Geranium"],
      base: ["Placeholder — e.g. Oakmoss", "Placeholder — e.g. Vetiver"],
    },
    description:
      "PLACEHOLDER DESCRIPTION — replace with your real product story. Keep it short: what it feels like to wear, and the mood it's built for.",
    isPlaceholder: true,
    featured: false,
  },
  {
    id: "rose-de-nuit",
    name: "Rose de Nuit",
    tagline: "Rose after dark — deep, not sweet.",
    price: 6800,
    sizes: [
      { label: "30 ml", ml: 30 },
      { label: "50 ml", ml: 50, priceOverride: 9200 },
    ],
    stock: "out-of-stock",
    concentration: "Eau de Parfum",
    family: "Floral",
    images: ["/products/rose-de-nuit-1.jpg"],
    notes: {
      top: ["Placeholder — e.g. Blackcurrant", "Placeholder — e.g. Litchi"],
      heart: ["Placeholder — e.g. Rose", "Placeholder — e.g. Patchouli"],
      base: ["Placeholder — e.g. Musk", "Placeholder — e.g. Amber"],
    },
    description:
      "PLACEHOLDER DESCRIPTION — replace with your real product story. Keep it short: what it feels like to wear, and the mood it's built for.",
    isPlaceholder: true,
    featured: false,
  },
  {
    id: "santal-mystique",
    name: "Santal Mystique",
    tagline: "Creamy sandalwood, close to the skin.",
    price: 7500,
    sizes: [
      { label: "30 ml", ml: 30 },
      { label: "50 ml", ml: 50, priceOverride: 10200 },
      { label: "100 ml", ml: 100, priceOverride: 14500 },
    ],
    stock: "in-stock",
    concentration: "Parfum",
    family: "Woody & Green",
    images: ["/products/santal-mystique-1.jpg"],
    notes: {
      top: ["Placeholder — e.g. Cardamom", "Placeholder — e.g. Nutmeg"],
      heart: ["Placeholder — e.g. Sandalwood", "Placeholder — e.g. Iris"],
      base: ["Placeholder — e.g. Tonka Bean", "Placeholder — e.g. Musk"],
    },
    description:
      "PLACEHOLDER DESCRIPTION — replace with your real product story. Keep it short: what it feels like to wear, and the mood it's built for.",
    isPlaceholder: true,
    featured: true,
  },
];

export const FRAGRANCE_FAMILIES = [
  "All",
  ...Array.from(new Set(PRODUCTS.map((p) => p.family))),
];

export function getProductById(id) {
  return PRODUCTS.find((p) => p.id === id);
}

export function getFeaturedProducts() {
  return PRODUCTS.filter((p) => p.featured);
}

export function getPriceForSize(product, size) {
  if (size && size.priceOverride) return size.priceOverride;
  return product.price;
}

export function formatNPR(amount) {
  return `Rs ${amount.toLocaleString("en-IN")}`;
}
