import SEO from "../components/SEO.jsx";
import { SITE } from "../data/siteConfig.js";

export default function PrivacyPolicy() {
  return (
    <>
      <SEO title="Privacy Policy" description="How AURENTUM collects, uses, and protects your information." />
      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Legal</span>
          <h1>Privacy Policy</h1>
        </div>
      </div>
      <div className="legal-page">
        <div className="container legal-content">
          <p className="legal-updated">Last updated: ⚠ PLACEHOLDER — add the date you publish this page.</p>

          <h2>1. Information We Collect</h2>
          <p>
            When you place an order or contact us, we collect the
            information you provide directly, which may include your name,
            phone number, email address, delivery address, and any notes
            you add to your order.
          </p>

          <h2>2. How We Use Your Information</h2>
          <ul>
            <li>To process and deliver your order</li>
            <li>To contact you about your order or an enquiry you've sent us</li>
            <li>To respond to questions sent through our contact form or WhatsApp</li>
          </ul>
          <p>
            We do not sell your personal information to third parties.
          </p>

          <h2>3. Order Data Storage</h2>
          <p>
            This website stores your shopping cart locally in your own
            browser (via localStorage) so items remain in your cart between
            visits. Order details you submit at checkout are used to
            complete that order; ⚠ PLACEHOLDER — describe how and where you
            actually store completed order records (e.g. a spreadsheet,
            order-management tool, or email inbox).
          </p>

          <h2>4. Cookies</h2>
          <p>
            This site does not use third-party advertising or tracking
            cookies. ⚠ PLACEHOLDER — update this section if you later add
            analytics or marketing tools.
          </p>

          <h2>5. Third-Party Services</h2>
          <p>
            We may use WhatsApp to communicate with you about your order if
            you choose that contact method. Messages sent this way are
            subject to WhatsApp's own privacy policy.
          </p>

          <h2>6. Your Rights</h2>
          <p>
            You may ask us to access, correct, or delete the personal
            information we hold about you by contacting us at{" "}
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a>.
          </p>

          <h2>7. Contact</h2>
          <p>
            Questions about this policy can be sent to{" "}
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a> or{" "}
            <a href={`tel:${SITE.phone.replace(/\s+/g, "")}`}>{SITE.phone}</a>.
          </p>
        </div>
      </div>
    </>
  );
}
