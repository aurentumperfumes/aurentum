import { useMemo, useState } from "react";
import SEO from "../components/SEO.jsx";
import ProductCard from "../components/ProductCard.jsx";
import Reveal from "../components/Reveal.jsx";
import { PRODUCTS, FRAGRANCE_FAMILIES } from "../data/products.js";

export default function Shop() {
  const [activeFamily, setActiveFamily] = useState("All");
  const [sort, setSort] = useState("featured");

  const products = useMemo(() => {
    let list =
      activeFamily === "All"
        ? [...PRODUCTS]
        : PRODUCTS.filter((p) => p.family === activeFamily);

    if (sort === "price-asc") list.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list.sort((a, b) => b.price - a.price);
    if (sort === "name") list.sort((a, b) => a.name.localeCompare(b.name));

    return list;
  }, [activeFamily, sort]);

  return (
    <>
      <SEO
        title="Shop"
        description="Shop the full AURENTUM fragrance collection. Filter by fragrance family and shop online with delivery across Nepal."
      />

      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">The Collection</span>
          <h1>Shop All Fragrances</h1>
          <p>
            Every AURENTUM fragrance, in one place. Filter by family to find
            the mood you're after.
          </p>
        </div>
      </div>

      <section className="section">
        <div className="container">
          <div className="shop-toolbar">
            {FRAGRANCE_FAMILIES.map((family) => (
              <button
                key={family}
                className={`filter-pill ${
                  activeFamily === family ? "is-active" : ""
                }`}
                onClick={() => setActiveFamily(family)}
                aria-pressed={activeFamily === family}
              >
                {family}
              </button>
            ))}
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              marginBottom: 28,
            }}
          >
            <label className="visually-hidden" htmlFor="sort-select">
              Sort products
            </label>
            <select
              id="sort-select"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              style={{ maxWidth: 220 }}
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="name">Name: A–Z</option>
            </select>
          </div>

          {products.length === 0 ? (
            <div className="shop-empty">
              <p>No fragrances in this family yet.</p>
            </div>
          ) : (
            <div className="product-grid">
              {products.map((product, i) => (
                <Reveal key={product.id} delay={(i % 6) * 60}>
                  <ProductCard product={product} index={i} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
