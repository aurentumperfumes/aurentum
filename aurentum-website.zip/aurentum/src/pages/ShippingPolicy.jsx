import SEO from "../components/SEO.jsx";
import { SITE } from "../data/siteConfig.js";
import { formatNPR } from "../data/products.js";

export default function ShippingPolicy() {
  return (
    <>
      <SEO title="Shipping Policy" description="Delivery times, areas, and shipping costs for AURENTUM orders." />
      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Legal</span>
          <h1>Shipping Policy</h1>
        </div>
      </div>
      <div className="legal-page">
        <div className="container legal-content">
          <p className="legal-updated">Last updated: ⚠ PLACEHOLDER — add the date you publish this page.</p>

          <h2>1. Delivery Areas</h2>
          <p>
            We currently deliver across Nepal. ⚠ PLACEHOLDER — confirm the
            exact regions or districts you can actually ship to.
          </p>

          <h2>2. Delivery Times</h2>
          <ul>
            <li>Inside the Kathmandu Valley: {SITE.shipping.estimateInsideValley} (⚠ placeholder estimate)</li>
            <li>Outside the Kathmandu Valley: {SITE.shipping.estimateOutsideValley} (⚠ placeholder estimate)</li>
          </ul>
          <p>
            Delivery times are estimates and may vary due to location,
            weather, or courier availability.
          </p>

          <h2>3. Shipping Cost</h2>
          <p>
            A flat shipping fee of {formatNPR(SITE.shipping.flatRate)} applies to
            orders below {formatNPR(SITE.shipping.freeShippingThreshold)}. Orders
            at or above {formatNPR(SITE.shipping.freeShippingThreshold)} ship free.
            ⚠ PLACEHOLDER — confirm these figures reflect your real shipping
            costs before launch.
          </p>

          <h2>4. Cash on Delivery</h2>
          <p>
            Cash on Delivery is available on all orders. Please have the
            exact order total ready for the courier where possible.
          </p>

          <h2>5. Order Tracking</h2>
          <p>
            ⚠ PLACEHOLDER — describe how customers can track their order
            (e.g. a phone call or WhatsApp update from your team) once you
            have a process in place.
          </p>

          <h2>6. Contact</h2>
          <p>
            Questions about a delivery can be sent to{" "}
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a> or{" "}
            <a href={`tel:${SITE.phone.replace(/\s+/g, "")}`}>{SITE.phone}</a>.
          </p>
        </div>
      </div>
    </>
  );
}
