import SEO from "../components/SEO.jsx";
import { SITE } from "../data/siteConfig.js";

export default function Terms() {
  return (
    <>
      <SEO title="Terms & Conditions" description="Terms and conditions for shopping with AURENTUM." />
      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Legal</span>
          <h1>Terms &amp; Conditions</h1>
        </div>
      </div>
      <div className="legal-page">
        <div className="container legal-content">
          <p className="legal-updated">Last updated: ⚠ PLACEHOLDER — add the date you publish this page.</p>

          <h2>1. About These Terms</h2>
          <p>
            These terms govern your use of the {SITE.brandName} website and
            any orders you place with us. By using this site or placing an
            order, you agree to these terms.
          </p>

          <h2>2. Products</h2>
          <p>
            We describe our fragrances as accurately as possible. Product
            images on this site currently include illustrative placeholder
            artwork where real photography has not yet been added — ⚠
            PLACEHOLDER — remove this note once genuine product photos are
            in place.
          </p>

          <h2>3. Pricing</h2>
          <p>
            All prices are listed in Nepali Rupees (NPR) and are subject to
            change without prior notice. The price charged is the price
            shown at checkout at the time you place your order.
          </p>

          <h2>4. Orders &amp; Payment</h2>
          <p>
            Orders can currently be placed with Cash on Delivery or by
            confirming your order via WhatsApp. Online card or wallet
            payment (such as eSewa or Khalti) is not yet available on this
            site.
          </p>

          <h2>5. Order Acceptance</h2>
          <p>
            We reserve the right to cancel or decline any order — for
            example if a product is out of stock or delivery is not
            possible to your address — and will contact you if this
            happens.
          </p>

          <h2>6. Intellectual Property</h2>
          <p>
            All content on this site, including the {SITE.brandName} name,
            logo, and product descriptions, belongs to {SITE.brandName} and
            may not be reproduced without permission.
          </p>

          <h2>7. Limitation of Liability</h2>
          <p>
            ⚠ PLACEHOLDER — this section should be reviewed by a qualified
            professional in your jurisdiction before publishing. Nothing on
            this page is legal advice.
          </p>

          <h2>8. Contact</h2>
          <p>
            Questions about these terms can be sent to{" "}
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a>.
          </p>
        </div>
      </div>
    </>
  );
}
