import { Link } from "react-router-dom";
import SEO from "../components/SEO.jsx";
import Reveal from "../components/Reveal.jsx";
import BottleArt from "../components/BottleArt.jsx";
import Divider from "../components/Divider.jsx";

const VALUES = [
  {
    title: "Composed, Not Copied",
    body: "Each fragrance is developed and tested in stages, refined until the drydown holds up as well as the opening.",
  },
  {
    title: "Honest Concentration",
    body: "We publish the real concentration on every bottle — Eau de Parfum or Parfum — so you know exactly what you're wearing.",
  },
  {
    title: "Built for Everyday Confidence",
    body: "AURENTUM is designed to be worn often, not saved for one occasion a year.",
  },
  {
    title: "Direct to You",
    body: "Sold online, shipped across Nepal, with a real person on WhatsApp if you have questions before you buy.",
  },
];

export default function About() {
  return (
    <>
      <SEO
        title="About"
        description="The AURENTUM story — an exclusive perfume house crafted for confidence."
      />

      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">About AURENTUM</span>
          <h1>Crafted For Confidence</h1>
          <p>
            A fragrance house built on restraint, quality composition, and
            scents designed to be worn — not just admired in the bottle.
          </p>
        </div>
      </div>

      <section className="section">
        <div className="container">
          <Reveal>
            <div className="story-split">
              <div className="story-copy">
                <span className="eyebrow">How It Started</span>
                <h2>A quieter kind of luxury.</h2>
                <p>
                  AURENTUM was founded on the belief that a signature scent
                  should feel personal, not performative. Too many
                  fragrances are designed to announce themselves the moment
                  you walk into a room. We wanted to build the opposite: a
                  collection that settles in, holds its shape through the
                  day, and lets confidence do the talking instead.
                </p>
                <p>
                  Every AURENTUM fragrance goes through rounds of refinement
                  before it's added to the collection — evaluated not just
                  on the first impression, but on how it wears three, six,
                  eight hours later.
                </p>
              </div>
              <div className="story-media" aria-hidden="true">
                <BottleArt variant="square" />
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section" style={{ background: "var(--bg-alt)" }}>
        <div className="container">
          <Reveal>
            <div className="section-head">
              <span className="eyebrow">What We Stand For</span>
              <h2>Our Values</h2>
            </div>
          </Reveal>
          <div className="values-grid">
            {VALUES.map((v, i) => (
              <Reveal key={v.title} delay={i * 80}>
                <div className="value-card">
                  <h3>{v.title}</h3>
                  <p>{v.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container" style={{ textAlign: "center" }}>
          <Reveal>
            <Divider />
            <p
              style={{
                maxWidth: 560,
                margin: "28px auto 34px",
                color: "var(--ink-soft)",
              }}
            >
              Ready to find your signature? Explore the full collection or
              reach out with any questions before you order.
            </p>
            <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
              <Link to="/shop" className="btn btn-primary">
                Shop the Collection
              </Link>
              <Link to="/contact" className="btn btn-ghost">
                Contact Us
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
