import { Link } from "react-router-dom";
import SEO from "../components/SEO.jsx";
import Divider from "../components/Divider.jsx";
import Reveal from "../components/Reveal.jsx";
import ProductCard from "../components/ProductCard.jsx";
import BottleArt from "../components/BottleArt.jsx";
import Sparkle from "../components/Sparkle.jsx";
import { getFeaturedProducts } from "../data/products.js";
import { SITE } from "../data/siteConfig.js";

const WHY = [
  {
    title: "Considered Composition",
    body: "Every fragrance is built in layers — top, heart and base — so it evolves honestly on your skin through the day.",
  },
  {
    title: "Quality Concentration",
    body: "We work in Eau de Parfum and Parfum strength for lasting presence, not a spray that fades by noon.",
  },
  {
    title: "Delivered With Care",
    body: "Ordered online, packed carefully, and shipped across Nepal with cash on delivery available.",
  },
];

export default function Home() {
  const featured = getFeaturedProducts();

  return (
    <>
      <SEO
        title="Home"
        description="AURENTUM — exclusive perfumes crafted for confidence. Shop the collection online with delivery across Nepal."
      />

      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-copy">
            <span className="eyebrow">Exclusive Perfumes</span>
            <h1>Crafted For Confidence</h1>
            <p className="hero-lede">
              AURENTUM is a fragrance house built around one idea: a scent
              should feel like an extension of your presence, not a
              distraction from it. Explore a collection composed for people
              who know exactly who they are.
            </p>
            <div className="hero-actions">
              <Link to="/shop" className="btn btn-primary">
                Shop the Collection
              </Link>
              <Link to="/about" className="btn btn-ghost">
                Our Story
              </Link>
            </div>
          </div>
          <div className="hero-media" aria-hidden="true">
            <BottleArt variant="classic" tone="accent" />
            <div className="hero-media-tag">
              <span>Eau de Parfum</span>
              <span>AURENTUM</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <Reveal>
            <div className="section-head">
              <span className="eyebrow">Featured</span>
              <h2>The Collection</h2>
              <p>
                A short list of signatures, each built around a distinct
                mood — warm and amber, bright and floral, or green and
                grounded.
              </p>
            </div>
          </Reveal>
          <div className="product-grid">
            {featured.map((product, i) => (
              <Reveal key={product.id} delay={i * 80}>
                <ProductCard product={product} index={i} />
              </Reveal>
            ))}
          </div>
          <Reveal>
            <div style={{ textAlign: "center", marginTop: 48 }}>
              <Link to="/shop" className="btn btn-accent">
                View All Fragrances
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section" style={{ background: "var(--bg-alt)" }}>
        <div className="container">
          <Reveal>
            <div className="story-split">
              <div className="story-media" aria-hidden="true">
                <BottleArt variant="round" />
              </div>
              <div className="story-copy">
                <span className="eyebrow">Our Story</span>
                <h2>Confidence, bottled.</h2>
                <p>
                  AURENTUM began with a simple frustration: most fragrances
                  are designed to be noticed first and worn second. We
                  wanted the opposite — a scent that settles into who you
                  already are, so it reads as quietly self-assured rather
                  than loud.
                </p>
                <p>
                  Each composition is developed and refined before it earns
                  a place in the collection. Nothing ships until it holds up
                  from the first spray to the final, softest trace hours
                  later.
                </p>
                <Link to="/about" className="btn btn-ghost">
                  Read Our Story
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <Reveal>
            <div className="section-head">
              <span className="eyebrow">Why AURENTUM</span>
              <h2>What We Stand For</h2>
            </div>
          </Reveal>
          <div className="why-grid">
            {WHY.map((item, i) => (
              <Reveal key={item.title} delay={i * 100}>
                <div className="why-item">
                  <div className="why-icon">
                    <Sparkle size={32} />
                  </div>
                  <h3>{item.title}</h3>
                  <p>{item.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <Reveal>
            <Divider />
          </Reveal>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <Reveal>
            <div className="insta-head">
              <h2>Follow @aurentum</h2>
              {SITE.social.instagram && (
                <a
                  href={SITE.social.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="nav-link"
                >
                  View on Instagram
                </a>
              )}
            </div>
          </Reveal>
          <Reveal>
            <div className="insta-grid">
              {Array.from({ length: 5 }).map((_, i) => (
                <div className="insta-tile" key={i}>
                  <Sparkle size={20} />
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="cta-band">
        <div className="container">
          <Reveal>
            <h2>Find your signature.</h2>
            <p>{SITE.tagline} — explore the full AURENTUM collection.</p>
            <Link to="/shop" className="btn">
              Shop Now
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
