import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import SEO from "../components/SEO.jsx";
import { useCart } from "../context/CartContext.jsx";
import { formatNPR } from "../data/products.js";
import { SITE } from "../data/siteConfig.js";
import { buildWhatsAppLink } from "../utils/whatsapp.js";

const EMPTY_FORM = {
  fullName: "",
  phone: "",
  email: "",
  province: "",
  city: "",
  address: "",
  note: "",
};

function generateOrderId() {
  const stamp = Date.now().toString(36).toUpperCase().slice(-6);
  return `AUR-${stamp}`;
}

export default function Checkout() {
  const { lines, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});
  const [paymentMethod, setPaymentMethod] = useState("cod");

  const shipping =
    lines.length === 0
      ? 0
      : subtotal >= SITE.shipping.freeShippingThreshold
      ? 0
      : SITE.shipping.flatRate;
  const total = subtotal + shipping;

  const whatsappHref = useMemo(() => buildWhatsAppLink({ lines }), [lines]);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function validate() {
    const next = {};
    if (!form.fullName.trim()) next.fullName = "Full name is required.";
    if (!form.phone.trim()) {
      next.phone = "Phone number is required.";
    } else if (!/^[0-9+\-\s]{7,15}$/.test(form.phone.trim())) {
      next.phone = "Enter a valid phone number.";
    }
    if (form.email.trim() && !/^\S+@\S+\.\S+$/.test(form.email.trim())) {
      next.email = "Enter a valid email address.";
    }
    if (!form.province) next.province = "Select a province.";
    if (!form.city.trim()) next.city = "City is required.";
    if (!form.address.trim()) next.address = "Delivery address is required.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (lines.length === 0) return;
    if (!validate()) return;

    const orderId = generateOrderId();
    const order = {
      orderId,
      form,
      paymentMethod,
      lines: lines.map((l) => ({
        name: l.product.name,
        size: l.size?.label,
        quantity: l.quantity,
        unitPrice: l.unitPrice,
        lineTotal: l.lineTotal,
      })),
      subtotal,
      shipping,
      total,
      placedAt: new Date().toISOString(),
    };

    try {
      window.sessionStorage.setItem("aurentum_last_order", JSON.stringify(order));
    } catch {
      /* sessionStorage unavailable — confirmation page will use fallback */
    }

    clearCart();
    navigate("/order-confirmation");
  }

  if (lines.length === 0) {
    return (
      <>
        <SEO title="Checkout" description="Complete your AURENTUM order." />
        <div className="section">
          <div className="container cart-empty">
            <span className="eyebrow">Checkout</span>
            <h1>Your cart is empty</h1>
            <p>Add a fragrance to your bag before checking out.</p>
            <Link to="/shop" className="btn btn-primary">
              Shop the Collection
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <SEO title="Checkout" description="Complete your AURENTUM order — cash on delivery available across Nepal." />

      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Checkout</span>
          <h1>Delivery Details</h1>
        </div>
      </div>

      <section className="section">
        <div className="container checkout-layout">
          <form className="checkout-panel" onSubmit={handleSubmit} noValidate>
            <h2>Contact &amp; Delivery</h2>

            <div className="form-row">
              <label htmlFor="fullName">Full Name</label>
              <input
                id="fullName"
                type="text"
                value={form.fullName}
                onChange={(e) => update("fullName", e.target.value)}
                autoComplete="name"
                required
              />
              {errors.fullName && <p className="form-error">{errors.fullName}</p>}
            </div>

            <div className="form-grid">
              <div className="form-row">
                <label htmlFor="phone">Phone Number</label>
                <input
                  id="phone"
                  type="tel"
                  value={form.phone}
                  onChange={(e) => update("phone", e.target.value)}
                  autoComplete="tel"
                  required
                />
                {errors.phone && <p className="form-error">{errors.phone}</p>}
              </div>
              <div className="form-row">
                <label htmlFor="email">Email (optional)</label>
                <input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                  autoComplete="email"
                />
                {errors.email && <p className="form-error">{errors.email}</p>}
              </div>
            </div>

            <div className="form-grid">
              <div className="form-row">
                <label htmlFor="province">Province</label>
                <select
                  id="province"
                  value={form.province}
                  onChange={(e) => update("province", e.target.value)}
                  required
                >
                  <option value="">Select province</option>
                  {SITE.provinces.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                {errors.province && <p className="form-error">{errors.province}</p>}
              </div>
              <div className="form-row">
                <label htmlFor="city">City</label>
                <input
                  id="city"
                  type="text"
                  value={form.city}
                  onChange={(e) => update("city", e.target.value)}
                  autoComplete="address-level2"
                  required
                />
                {errors.city && <p className="form-error">{errors.city}</p>}
              </div>
            </div>

            <div className="form-row">
              <label htmlFor="address">Full Delivery Address</label>
              <textarea
                id="address"
                rows="3"
                value={form.address}
                onChange={(e) => update("address", e.target.value)}
                autoComplete="street-address"
                required
              />
              {errors.address && <p className="form-error">{errors.address}</p>}
            </div>

            <div className="form-row">
              <label htmlFor="note">Delivery Note (optional)</label>
              <textarea
                id="note"
                rows="2"
                placeholder="e.g. landmark, preferred delivery time"
                value={form.note}
                onChange={(e) => update("note", e.target.value)}
              />
            </div>

            <h2 style={{ marginTop: 34 }}>Payment</h2>

            <label
              className={`payment-option ${
                paymentMethod === "cod" ? "is-active" : ""
              }`}
            >
              <input
                type="radio"
                name="payment"
                value="cod"
                checked={paymentMethod === "cod"}
                onChange={() => setPaymentMethod("cod")}
              />
              <span>
                <strong>Cash on Delivery</strong>
                <span>Pay in cash when your order arrives.</span>
              </span>
            </label>

            <label
              className={`payment-option ${
                paymentMethod === "whatsapp" ? "is-active" : ""
              }`}
            >
              <input
                type="radio"
                name="payment"
                value="whatsapp"
                checked={paymentMethod === "whatsapp"}
                onChange={() => setPaymentMethod("whatsapp")}
              />
              <span>
                <strong>Order via WhatsApp</strong>
                <span>
                  Send your order details to us directly and we'll confirm
                  payment and delivery together.
                </span>
              </span>
            </label>

            <p className="order-note">
              Online card/wallet payment (eSewa, Khalti) is not yet
              connected — please choose Cash on Delivery or WhatsApp for
              now.
            </p>

            {paymentMethod === "whatsapp" ? (
              <a
                href={whatsappHref}
                target="_blank"
                rel="noreferrer"
                className="btn btn-primary btn-block"
                style={{ marginTop: 22 }}
              >
                Continue on WhatsApp
              </a>
            ) : (
              <button type="submit" className="btn btn-primary btn-block" style={{ marginTop: 22 }}>
                Place Order — Cash on Delivery
              </button>
            )}
          </form>

          <aside className="cart-summary">
            <h2>Order Summary</h2>
            <div className="checkout-summary-list">
              {lines.map((l) => (
                <div className="checkout-summary-line" key={l.key}>
                  <span>
                    {l.product.name} ({l.size?.label}) × {l.quantity}
                  </span>
                  <span>{formatNPR(l.lineTotal)}</span>
                </div>
              ))}
            </div>
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatNPR(subtotal)}</span>
            </div>
            <div className="summary-row">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : formatNPR(shipping)}</span>
            </div>
            <div className="summary-row total">
              <span>Total</span>
              <span>{formatNPR(total)}</span>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
