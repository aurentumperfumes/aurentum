import { Link, useNavigate } from "react-router-dom";
import SEO from "../components/SEO.jsx";
import BottleArt from "../components/BottleArt.jsx";
import { useCart } from "../context/CartContext.jsx";
import { formatNPR } from "../data/products.js";
import { SITE } from "../data/siteConfig.js";
import { buildWhatsAppLink } from "../utils/whatsapp.js";

export default function Cart() {
  const { lines, subtotal, setQuantity, removeItem, clearCart } = useCart();
  const navigate = useNavigate();

  const shipping =
    lines.length === 0
      ? 0
      : subtotal >= SITE.shipping.freeShippingThreshold
      ? 0
      : SITE.shipping.flatRate;

  const total = subtotal + shipping;

  if (lines.length === 0) {
    return (
      <>
        <SEO title="Your Cart" description="Your AURENTUM shopping cart." />
        <div className="section">
          <div className="container cart-empty">
            <span className="eyebrow">Cart</span>
            <h1>Your cart is empty</h1>
            <p>Browse the collection to find your next signature scent.</p>
            <Link to="/shop" className="btn btn-primary">
              Shop the Collection
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <SEO title="Your Cart" description="Review your AURENTUM shopping cart." />
      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Cart</span>
          <h1>Your Bag</h1>
        </div>
      </div>

      <section className="section">
        <div className="container cart-layout">
          <div>
            {lines.map((line) => (
              <div className="cart-line" key={line.key}>
                <div className="cart-line-media">
                  <BottleArt variant="classic" label={line.product.name} />
                </div>
                <div>
                  <div className="cart-line-name">
                    <Link to={`/shop/${line.product.id}`}>
                      {line.product.name}
                    </Link>
                  </div>
                  <div className="cart-line-meta">
                    {line.size?.label} · {formatNPR(line.unitPrice)} each
                  </div>
                  <div className="cart-line-actions">
                    <div className="qty-control">
                      <button
                        onClick={() =>
                          setQuantity(line.key, line.quantity - 1)
                        }
                        aria-label={`Decrease quantity of ${line.product.name}`}
                      >
                        −
                      </button>
                      <span aria-live="polite">{line.quantity}</span>
                      <button
                        onClick={() =>
                          setQuantity(line.key, Math.min(10, line.quantity + 1))
                        }
                        aria-label={`Increase quantity of ${line.product.name}`}
                      >
                        +
                      </button>
                    </div>
                    <button
                      className="cart-line-remove"
                      onClick={() => removeItem(line.key)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
                <div className="cart-line-total">
                  {formatNPR(line.lineTotal)}
                </div>
              </div>
            ))}

            <div className="cart-actions-row">
              <button className="btn btn-ghost btn-sm" onClick={clearCart}>
                Clear Cart
              </button>
              <Link to="/shop" className="nav-link">
                ← Continue Shopping
              </Link>
            </div>
          </div>

          <aside className="cart-summary">
            <h2>Order Summary</h2>
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatNPR(subtotal)}</span>
            </div>
            <div className="summary-row">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : formatNPR(shipping)}</span>
            </div>
            {shipping > 0 && (
              <p className="order-note">
                Free shipping on orders over{" "}
                {formatNPR(SITE.shipping.freeShippingThreshold)}.
              </p>
            )}
            <div className="summary-row total">
              <span>Total</span>
              <span>{formatNPR(total)}</span>
            </div>
            <button
              className="btn btn-primary btn-block"
              style={{ marginTop: 20 }}
              onClick={() => navigate("/checkout")}
            >
              Proceed to Checkout
            </button>
            <a
              href={buildWhatsAppLink({ lines })}
              target="_blank"
              rel="noreferrer"
              className="whatsapp-link"
              style={{ marginTop: 16, display: "flex", justifyContent: "center" }}
            >
              Order via WhatsApp →
            </a>
          </aside>
        </div>
      </section>
    </>
  );
}
