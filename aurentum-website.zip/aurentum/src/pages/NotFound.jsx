import { Link } from "react-router-dom";
import SEO from "../components/SEO.jsx";

export default function NotFound() {
  return (
    <>
      <SEO title="Page Not Found" description="The page you're looking for doesn't exist." />
      <div className="container notfound">
        <h1>404</h1>
        <p>The page you're looking for doesn't exist or may have moved.</p>
        <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
          <Link to="/" className="btn btn-primary">
            Back to Home
          </Link>
          <Link to="/shop" className="btn btn-ghost">
            Shop the Collection
          </Link>
        </div>
      </div>
    </>
  );
}
