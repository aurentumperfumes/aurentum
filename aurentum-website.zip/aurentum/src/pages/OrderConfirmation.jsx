import { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import SEO from "../components/SEO.jsx";
import { formatNPR } from "../data/products.js";
import { SITE } from "../data/siteConfig.js";

export default function OrderConfirmation() {
  const [order, setOrder] = useState(undefined); // undefined = loading, null = none found

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem("aurentum_last_order");
      setOrder(raw ? JSON.parse(raw) : null);
    } catch {
      setOrder(null);
    }
  }, []);

  if (order === undefined) return null;

  if (!order) {
    return <Navigate to="/shop" replace />;
  }

  return (
    <>
      <SEO title="Order Confirmed" description="Your AURENTUM order has been placed." />

      <div className="section">
        <div className="container confirmation">
          <div className="confirmation-icon" aria-hidden="true">
            <svg viewBox="0 0 64 64" fill="none">
              <circle cx="32" cy="32" r="30" stroke="currentColor" strokeWidth="1.3" />
              <path
                d="M20 33l8 8 16-18"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <span className="eyebrow">Thank You</span>
          <h1>Your order is confirmed</h1>
          <p>
            We've received your order and will reach out at{" "}
            {order.form?.phone || "the number you provided"} to confirm
            delivery details. Payment: {order.paymentMethod === "cod" ? "Cash on Delivery" : "WhatsApp"}.
          </p>
          <span className="confirmation-order-id">{order.orderId}</span>

          <div className="checkout-summary-list" style={{ maxWidth: 480, margin: "0 auto 30px", textAlign: "left" }}>
            {order.lines.map((l, i) => (
              <div className="checkout-summary-line" key={i}>
                <span>
                  {l.name} ({l.size}) × {l.quantity}
                </span>
                <span>{formatNPR(l.lineTotal)}</span>
              </div>
            ))}
            <div className="summary-row total" style={{ marginTop: 10 }}>
              <span>Total</span>
              <span>{formatNPR(order.total)}</span>
            </div>
          </div>

          <p style={{ fontSize: "0.85rem" }}>
            Questions about your order? Reach us at{" "}
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a> or{" "}
            <a href={`tel:${SITE.phone.replace(/\s+/g, "")}`}>{SITE.phone}</a>.
          </p>

          <div className="confirmation-actions">
            <Link to="/shop" className="btn btn-primary">
              Continue Shopping
            </Link>
            <Link to="/" className="btn btn-ghost">
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
