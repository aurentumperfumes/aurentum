import { useState } from "react";
import SEO from "../components/SEO.jsx";
import { SITE } from "../data/siteConfig.js";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function validate() {
    const next = {};
    if (!form.name.trim()) next.name = "Please enter your name.";
    if (!form.email.trim() || !/^\S+@\S+\.\S+$/.test(form.email.trim())) {
      next.email = "Please enter a valid email address.";
    }
    if (!form.message.trim()) next.message = "Please enter a message.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!validate()) return;

    const subject = encodeURIComponent(`Website enquiry from ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`);
    window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`;
    setSent(true);
  }

  return (
    <>
      <SEO
        title="Contact"
        description="Get in touch with AURENTUM — questions about fragrances, orders, or delivery."
      />

      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Contact</span>
          <h1>We'd Love to Hear From You</h1>
          <p>
            Questions about a fragrance, an existing order, or delivery?
            Reach out — a real person reads every message.
          </p>
        </div>
      </div>

      <section className="section">
        <div className="container contact-layout">
          <form onSubmit={handleSubmit} className="checkout-panel" noValidate>
            <h2>Send a Message</h2>

            {sent && (
              <p className="form-success">
                Your email app should now be open with your message ready to
                send. If it didn't open, email us directly at{" "}
                <a href={`mailto:${SITE.email}`}>{SITE.email}</a>.
              </p>
            )}

            <div className="form-row">
              <label htmlFor="name">Your Name</label>
              <input
                id="name"
                type="text"
                value={form.name}
                onChange={(e) => update("name", e.target.value)}
                autoComplete="name"
                required
              />
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>

            <div className="form-row">
              <label htmlFor="email">Email Address</label>
              <input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                autoComplete="email"
                required
              />
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>

            <div className="form-row">
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                rows="5"
                value={form.message}
                onChange={(e) => update("message", e.target.value)}
                required
              />
              {errors.message && <p className="form-error">{errors.message}</p>}
            </div>

            <button type="submit" className="btn btn-primary btn-block">
              Send Message
            </button>
          </form>

          <div className="contact-info-card">
            <h3>Get In Touch</h3>
            <p style={{ color: "var(--ink-soft)", fontSize: "0.9rem" }}>
              Prefer a faster reply? Message us on WhatsApp.
            </p>

            <div className="contact-info-row">
              <span>Email</span>
              <a href={`mailto:${SITE.email}`}>{SITE.email}</a>
            </div>
            <div className="contact-info-row">
              <span>Phone</span>
              <a href={`tel:${SITE.phone.replace(/\s+/g, "")}`}>{SITE.phone}</a>
            </div>
            <div className="contact-info-row">
              <span>WhatsApp</span>
              <a
                href={`https://wa.me/${SITE.whatsappNumber}`}
                target="_blank"
                rel="noreferrer"
              >
                Message us on WhatsApp →
              </a>
            </div>
            <div className="contact-info-row">
              <span>Address</span>
              {SITE.address}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
