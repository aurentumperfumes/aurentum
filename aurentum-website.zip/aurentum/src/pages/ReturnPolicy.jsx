import SEO from "../components/SEO.jsx";
import { SITE } from "../data/siteConfig.js";

export default function ReturnPolicy() {
  return (
    <>
      <SEO title="Return & Refund Policy" description="AURENTUM's return and refund policy." />
      <div className="page-hero">
        <div className="container">
          <span className="eyebrow">Legal</span>
          <h1>Return &amp; Refund Policy</h1>
        </div>
      </div>
      <div className="legal-page">
        <div className="container legal-content">
          <p className="legal-updated">Last updated: ⚠ PLACEHOLDER — add the date you publish this page.</p>

          <h2>1. Eligibility for Returns</h2>
          <p>
            ⚠ PLACEHOLDER — for hygiene and safety reasons, many fragrance
            brands only accept returns of sealed, unopened bottles within a
            set number of days of delivery. Decide your real policy and
            replace this section before launch.
          </p>

          <h2>2. Damaged or Incorrect Items</h2>
          <p>
            If your order arrives damaged or you receive the wrong item,
            contact us within ⚠ PLACEHOLDER (e.g. 48 hours) of delivery with
            your order number and a photo of the item, and we will arrange
            a replacement or refund.
          </p>

          <h2>3. How to Request a Return</h2>
          <p>
            Email <a href={`mailto:${SITE.email}`}>{SITE.email}</a> or
            message us on WhatsApp with your order number and the reason
            for your return. We'll confirm next steps with you directly.
          </p>

          <h2>4. Refunds</h2>
          <p>
            ⚠ PLACEHOLDER — describe how refunds are issued for Cash on
            Delivery orders (e.g. bank transfer, mobile wallet) since no
            online payment gateway is currently connected to this site.
          </p>

          <h2>5. Non-Returnable Items</h2>
          <ul>
            <li>Opened or used bottles, unless faulty on arrival</li>
            <li>⚠ PLACEHOLDER — add any other exclusions specific to your business</li>
          </ul>

          <h2>6. Contact</h2>
          <p>
            Questions about a return can be sent to{" "}
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a> or{" "}
            <a href={`tel:${SITE.phone.replace(/\s+/g, "")}`}>{SITE.phone}</a>.
          </p>
        </div>
      </div>
    </>
  );
}
