import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import SEO from "../components/SEO.jsx";
import BottleArt from "../components/BottleArt.jsx";
import ProductCard from "../components/ProductCard.jsx";
import { getProductById, getPriceForSize, formatNPR, PRODUCTS } from "../data/products.js";
import { useCart } from "../context/CartContext.jsx";
import { buildWhatsAppLink } from "../utils/whatsapp.js";
import NotFound from "./NotFound.jsx";

const VARIANTS = ["classic", "round", "square"];

export default function Product() {
  const { productId } = useParams();
  const product = getProductById(productId);
  const navigate = useNavigate();
  const { addItem } = useCart();

  const [sizeLabel, setSizeLabel] = useState(product?.sizes[0]?.label);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [justAdded, setJustAdded] = useState(false);

  const size = useMemo(
    () => product?.sizes.find((s) => s.label === sizeLabel),
    [product, sizeLabel]
  );

  const related = useMemo(() => {
    if (!product) return [];
    return PRODUCTS.filter(
      (p) => p.id !== product.id && p.family === product.family
    ).slice(0, 3);
  }, [product]);

  if (!product) return <NotFound />;

  const unitPrice = getPriceForSize(product, size);
  const outOfStock = product.stock === "out-of-stock";
  const variant = VARIANTS[PRODUCTS.findIndex((p) => p.id === product.id) % 3];

  function handleAddToCart() {
    addItem(product.id, sizeLabel, quantity);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 2200);
  }

  function handleBuyNow() {
    addItem(product.id, sizeLabel, quantity);
    navigate("/checkout");
  }

  const whatsappHref = buildWhatsAppLink({ product, size, quantity });

  return (
    <>
      <SEO
        title={product.name}
        description={`${product.name} — ${product.tagline} ${formatNPR(
          product.price
        )}. Shop AURENTUM online.`}
      />

      <div className="product-detail">
        <div className="container">
          <p className="breadcrumb">
            <Link to="/">Home</Link> / <Link to="/shop">Shop</Link> /{" "}
            {product.name}
          </p>

          <div className="product-detail-grid">
            <div>
              <div className="product-gallery-main">
                <BottleArt
                  variant={
                    activeImage % 2 === 0 ? variant : VARIANTS[(VARIANTS.indexOf(variant) + 1) % 3]
                  }
                  label={product.name}
                  tone="accent"
                />
              </div>
              {product.images.length > 1 && (
                <div className="product-gallery-thumbs">
                  {product.images.map((_, i) => (
                    <button
                      key={i}
                      className={`gallery-thumb ${
                        activeImage === i ? "is-active" : ""
                      }`}
                      onClick={() => setActiveImage(i)}
                      aria-label={`View image ${i + 1} of ${product.name}`}
                      aria-pressed={activeImage === i}
                    >
                      <BottleArt variant={variant} label={product.name} />
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="product-info">
              <span className="eyebrow">
                {product.family} · {product.concentration}
              </span>
              <h1>{product.name}</h1>
              <p className="product-tagline">{product.tagline}</p>
              <span className="price">
                {formatNPR(unitPrice)}
                <small>{sizeLabel}</small>
              </span>

              {product.isPlaceholder && (
                <p className="placeholder-note">
                  Sample data — replace with real product details in
                  src/data/products.js before launch.
                </p>
              )}

              <p className="product-description">{product.description}</p>

              <div className="selector-block">
                <span className="selector-label">Size</span>
                <div className="size-options">
                  {product.sizes.map((s) => (
                    <button
                      key={s.label}
                      className={`size-option ${
                        sizeLabel === s.label ? "is-active" : ""
                      }`}
                      onClick={() => setSizeLabel(s.label)}
                      aria-pressed={sizeLabel === s.label}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="selector-block">
                <span className="selector-label">Quantity</span>
                <div className="qty-control">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label="Decrease quantity"
                    disabled={outOfStock}
                  >
                    −
                  </button>
                  <span aria-live="polite">{quantity}</span>
                  <button
                    onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                    aria-label="Increase quantity"
                    disabled={outOfStock}
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="product-actions">
                <button
                  className="btn btn-primary"
                  onClick={handleAddToCart}
                  disabled={outOfStock}
                >
                  {outOfStock
                    ? "Out of Stock"
                    : justAdded
                    ? "Added ✓"
                    : "Add to Cart"}
                </button>
                <button
                  className="btn btn-accent"
                  onClick={handleBuyNow}
                  disabled={outOfStock}
                >
                  Buy Now
                </button>
              </div>

              <a
                href={whatsappHref}
                target="_blank"
                rel="noreferrer"
                className="whatsapp-link"
                style={{ marginTop: 20, display: "inline-flex" }}
              >
                Order via WhatsApp →
              </a>

              <div className="notes-pyramid">
                <div className="notes-col">
                  <h4>Top Notes</h4>
                  <ul>
                    {product.notes.top.map((n) => (
                      <li key={n}>{n}</li>
                    ))}
                  </ul>
                </div>
                <div className="notes-col">
                  <h4>Heart Notes</h4>
                  <ul>
                    {product.notes.heart.map((n) => (
                      <li key={n}>{n}</li>
                    ))}
                  </ul>
                </div>
                <div className="notes-col">
                  <h4>Base Notes</h4>
                  <ul>
                    {product.notes.base.map((n) => (
                      <li key={n}>{n}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="section related-section">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">You May Also Like</span>
              <h2>More {product.family}</h2>
            </div>
            <div className="product-grid">
              {related.map((p, i) => (
                <ProductCard product={p} index={i} key={p.id} />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
