import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
} from "react";
import { getProductById, getPriceForSize } from "../data/products.js";

const CartContext = createContext(null);
const STORAGE_KEY = "aurentum_cart_v1";

function lineKey(productId, sizeLabel) {
  return `${productId}__${sizeLabel}`;
}

function loadInitialState() {
  if (typeof window === "undefined") return { items: [] };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { items: [] };
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed?.items)) return parsed;
    return { items: [] };
  } catch {
    return { items: [] };
  }
}

function reducer(state, action) {
  switch (action.type) {
    case "ADD": {
      const { productId, sizeLabel, quantity } = action.payload;
      const key = lineKey(productId, sizeLabel);
      const existing = state.items.find((i) => i.key === key);
      if (existing) {
        return {
          items: state.items.map((i) =>
            i.key === key ? { ...i, quantity: i.quantity + quantity } : i
          ),
        };
      }
      return {
        items: [
          ...state.items,
          { key, productId, sizeLabel, quantity },
        ],
      };
    }
    case "SET_QUANTITY": {
      const { key, quantity } = action.payload;
      if (quantity <= 0) {
        return { items: state.items.filter((i) => i.key !== key) };
      }
      return {
        items: state.items.map((i) =>
          i.key === key ? { ...i, quantity } : i
        ),
      };
    }
    case "REMOVE": {
      return { items: state.items.filter((i) => i.key !== action.payload.key) };
    }
    case "CLEAR": {
      return { items: [] };
    }
    default:
      return state;
  }
}

export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadInitialState);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* storage unavailable — cart still works for this session */
    }
  }, [state]);

  const lines = useMemo(() => {
    return state.items
      .map((item) => {
        const product = getProductById(item.productId);
        if (!product) return null;
        const size = product.sizes.find((s) => s.label === item.sizeLabel);
        const unitPrice = getPriceForSize(product, size);
        return {
          ...item,
          product,
          size,
          unitPrice,
          lineTotal: unitPrice * item.quantity,
        };
      })
      .filter(Boolean);
  }, [state.items]);

  const subtotal = useMemo(
    () => lines.reduce((sum, l) => sum + l.lineTotal, 0),
    [lines]
  );

  const itemCount = useMemo(
    () => lines.reduce((sum, l) => sum + l.quantity, 0),
    [lines]
  );

  const value = {
    lines,
    subtotal,
    itemCount,
    addItem: (productId, sizeLabel, quantity = 1) =>
      dispatch({ type: "ADD", payload: { productId, sizeLabel, quantity } }),
    setQuantity: (key, quantity) =>
      dispatch({ type: "SET_QUANTITY", payload: { key, quantity } }),
    removeItem: (key) => dispatch({ type: "REMOVE", payload: { key } }),
    clearCart: () => dispatch({ type: "CLEAR" }),
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}
