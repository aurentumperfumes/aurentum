import { SITE } from "../data/siteConfig.js";
import { formatNPR } from "../data/products.js";

/**
 * Builds a wa.me link pre-filled with an order message.
 * Accepts either a single product+size, or an array of cart lines.
 */
export function buildWhatsAppLink({ product, size, quantity, lines }) {
  let message = `Hello AURENTUM, I'd like to order:\n`;

  if (lines && lines.length) {
    lines.forEach((l) => {
      message += `• ${l.product.name} (${l.size?.label || ""}) x${l.quantity} — ${formatNPR(
        l.lineTotal
      )}\n`;
    });
  } else if (product) {
    message += `• ${product.name} (${size?.label || ""}) x${quantity || 1}\n`;
  }

  message += `\nPlease confirm availability and delivery details. Thank you!`;

  const encoded = encodeURIComponent(message);
  return `https://wa.me/${SITE.whatsappNumber}?text=${encoded}`;
}
