export default function Sparkle({ size = 14, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 32"
      fill="currentColor"
      className={`sparkle ${className}`}
      aria-hidden="true"
    >
      <path d="M12 0c0.6 6.2 1.7 9.4 4.2 11.8 2.5 2.5 5.7 3.6 7.8 4.2-2.1 0.6-5.3 1.7-7.8 4.2C13.7 22.6 12.6 25.8 12 32c-0.6-6.2-1.7-9.4-4.2-11.8C5.3 17.7 2.1 16.6 0 16c2.1-0.6 5.3-1.7 7.8-4.2C10.3 9.4 11.4 6.2 12 0z" />
    </svg>
  );
}
