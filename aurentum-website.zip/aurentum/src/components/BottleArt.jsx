const VARIANTS = {
  classic: (
    <>
      <rect x="42" y="14" width="16" height="12" rx="2" />
      <rect x="46" y="8" width="8" height="8" rx="1.5" />
      <path d="M36 30 C36 26 40 26 40 26 L60 26 C60 26 64 26 64 30 L67 108 C67 116 60 122 50 122 C40 122 33 116 33 108 Z" />
      <line x1="33" y1="52" x2="67" y2="52" />
      <line x1="40" y1="70" x2="60" y2="70" />
    </>
  ),
  round: (
    <>
      <rect x="43" y="12" width="14" height="10" rx="2" />
      <circle cx="50" cy="10" r="4" />
      <path d="M38 26 C34 26 32 32 32 40 L32 96 C32 112 40 124 50 124 C60 124 68 112 68 96 L68 40 C68 32 66 26 62 26 Z" />
      <line x1="32" y1="58" x2="68" y2="58" />
    </>
  ),
  square: (
    <>
      <rect x="41" y="10" width="18" height="14" rx="2" />
      <rect x="30" y="24" width="40" height="98" rx="4" />
      <line x1="30" y1="46" x2="70" y2="46" />
      <line x1="38" y1="90" x2="62" y2="90" />
    </>
  ),
};

/**
 * Line-art placeholder illustration standing in for real product
 * photography. Swap it out by adding real images via src/data/products.js.
 */
export default function BottleArt({
  variant = "classic",
  label,
  tone = "ink",
  className = "",
}) {
  const shape = VARIANTS[variant] || VARIANTS.classic;
  const stroke = tone === "accent" ? "var(--accent)" : "var(--ink)";

  return (
    <svg
      viewBox="0 0 100 140"
      className={`bottle-art ${className}`}
      role="img"
      aria-label={label ? `${label} — illustrative bottle placeholder` : "Illustrative bottle placeholder"}
    >
      <g
        fill="none"
        stroke={stroke}
        strokeWidth="1"
        strokeLinejoin="round"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      >
        {shape}
      </g>
    </svg>
  );
}
