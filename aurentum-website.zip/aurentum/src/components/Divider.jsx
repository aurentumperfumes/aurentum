import Sparkle from "./Sparkle.jsx";

export default function Divider() {
  return (
    <div className="divider" role="presentation">
      <span className="rule" />
      <Sparkle size={13} />
      <span className="rule" />
    </div>
  );
}
