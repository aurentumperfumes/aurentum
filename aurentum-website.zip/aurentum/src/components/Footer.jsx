import { Link } from "react-router-dom";
import Logo from "./Logo.jsx";
import { SITE } from "../data/siteConfig.js";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <Logo variant="mark" className="footer-logo" />
          <p>{SITE.tagline}</p>
          <div className="footer-social">
            {SITE.social.instagram && (
              <a href={SITE.social.instagram} target="_blank" rel="noreferrer">
                Instagram
              </a>
            )}
            {SITE.social.facebook && (
              <a href={SITE.social.facebook} target="_blank" rel="noreferrer">
                Facebook
              </a>
            )}
            {SITE.social.tiktok && (
              <a href={SITE.social.tiktok} target="_blank" rel="noreferrer">
                TikTok
              </a>
            )}
          </div>
        </div>

        <div className="footer-col">
          <h3>Shop</h3>
          <ul>
            <li><Link to="/shop">All Fragrances</Link></li>
            <li><Link to="/about">Our Story</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        <div className="footer-col">
          <h3>Support</h3>
          <ul>
            <li><Link to="/shipping-policy">Shipping Policy</Link></li>
            <li><Link to="/return-policy">Returns &amp; Refunds</Link></li>
            <li><Link to="/terms">Terms &amp; Conditions</Link></li>
            <li><Link to="/privacy-policy">Privacy Policy</Link></li>
          </ul>
        </div>

        <div className="footer-col">
          <h3>Get in touch</h3>
          <ul>
            <li><a href={`mailto:${SITE.email}`}>{SITE.email}</a></li>
            <li><a href={`tel:${SITE.phone.replace(/\s+/g, "")}`}>{SITE.phone}</a></li>
            <li>{SITE.address}</li>
          </ul>
        </div>
      </div>

      <div className="container footer-bottom">
        <p>
          © {year} {SITE.brandName}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
