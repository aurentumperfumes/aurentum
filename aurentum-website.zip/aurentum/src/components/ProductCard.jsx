import { Link } from "react-router-dom";
import BottleArt from "./BottleArt.jsx";
import { formatNPR } from "../data/products.js";

const VARIANTS = ["classic", "round", "square"];

const STOCK_LABEL = {
  "in-stock": null,
  "low-stock": "Only a few left",
  "out-of-stock": "Out of stock",
};

export default function ProductCard({ product, index = 0 }) {
  const variant = VARIANTS[index % VARIANTS.length];
  const stockLabel = STOCK_LABEL[product.stock];

  return (
    <article className="product-card">
      <Link to={`/shop/${product.id}`} className="product-card-media">
        <BottleArt variant={variant} label={product.name} />
        {stockLabel && (
          <span
            className={`stock-flag ${
              product.stock === "out-of-stock" ? "is-out" : ""
            }`}
          >
            {stockLabel}
          </span>
        )}
      </Link>
      <div className="product-card-body">
        <span className="eyebrow product-card-family">{product.family}</span>
        <h3>
          <Link to={`/shop/${product.id}`}>{product.name}</Link>
        </h3>
        <p className="product-card-tagline">{product.tagline}</p>
        <div className="product-card-foot">
          <span className="price">{formatNPR(product.price)}</span>
          <span className="product-card-size">{product.sizes[0].label}</span>
        </div>
      </div>
    </article>
  );
}
