import { Link } from "react-router-dom";

export default function Logo({ variant = "full", className = "" }) {
  const src =
    variant === "mark"
      ? "/brand/aurentum-mark-full.png"
      : "/brand/aurentum-wordmark.png";

  return (
    <Link to="/" className={`logo ${className}`} aria-label="AURENTUM — home">
      <img
        src={src}
        alt="AURENTUM — Exclusive Perfumes"
        className="logo-img"
      />
    </Link>
  );
}
